from django.urls import path
from . import views

urlpatterns = [
    # path('', views.home, name='home'),
path('', views.user_login, name='login'),
path('home/', views.home, name='home'),
    path('products/', views.products, name='products'),
    # path('login/', views.user_login, name='login'),
    path('users/', views.users_list, name='users'),
path('add-to-cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
path('cart/', views.cart_view, name='cart'),
path('buy/', views.buy_now, name='buy_now'),
path('remove-from-cart/<int:product_id>/', views.remove_from_cart, name='remove_from_cart'),
path('increase/<int:product_id>/', views.increase_cart, name='increase_cart'),
path('decrease/<int:product_id>/', views.decrease_cart, name='decrease_cart'),
path('manage-products/', views.manage_products, name='manage_products'),
path('delete-product/<int:product_id>/', views.delete_product, name='delete_product'),
path('edit-product/<int:product_id>/', views.edit_product, name='edit_product'),
]