from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, UserAccount
from .models import UserAccount



def home(request):
    products = Product.objects.all()
    return render(request, 'home.html', {'products': products})

def products(request):
    products = Product.objects.all()
    return render(request, 'products.html', {'products': products})

# def user_login(request):
#     message = ""
#
#     if request.method == 'POST':
#         action = request.POST.get('action')
#
#         if action == 'login':
#             username = request.POST.get('username')
#             password = request.POST.get('password')
#
#             user = UserAccount.objects.filter(username=username, password=password).first()
#
#             if user:
#                 return redirect('home')
#             else:
#                 message = "Invalid username or password"
#
#         elif action == 'signup':
#             username = request.POST.get('new_username')
#             password = request.POST.get('new_password')
#
#             if not UserAccount.objects.filter(username=username).exists():
#                 UserAccount.objects.create(username=username, password=password)
#                 message = "Account created successfully"
#             else:
#                 message = "Username already exists"
#
#     return render(request, 'user_login.html', {'message': message})

# def user_login(request):
#     message = ""
#
#     if request.method == 'POST':
#         action = request.POST.get('action')
#
#         if action == 'login':
#             username = request.POST.get('username')
#             password = request.POST.get('password')
#
#             user = UserAccount.objects.filter(
#                 username=username,
#                 password=password
#             ).first()
#
#             if user:
#                 return redirect('home')
#             else:
#                 message = "Invalid username or password"
#
#         elif action == 'signup':
#             username = request.POST.get('new_username')
#             password = request.POST.get('new_password')
#
#             if not UserAccount.objects.filter(username=username).exists():
#                 UserAccount.objects.create(
#                     username=username,
#                     password=password
#                 )
#                 return redirect('home')   # redirects after sign up
#             else:
#                 message = "Username already exists"
#
#     return render(request, 'user_login.html', {'message': message})

# def user_login(request):
#     message = ""
#
#     if request.method == 'POST':
#         action = request.POST.get('action')
#
#         if action == 'login':
#             username = request.POST.get('username', '').strip()
#             password = request.POST.get('password', '').strip()
#
#             user = UserAccount.objects.filter(
#                 username=username,
#                 password=password
#             ).first()
#
#             if user is not None:
#                 return redirect('/')
#             else:
#                 message = "Wrong username or password"
#
#         elif action == 'signup':
#             username = request.POST.get('new_username', '').strip()
#             password = request.POST.get('new_password', '').strip()
#
#             if username and password:
#                 UserAccount.objects.create(
#                     username=username,
#                     password=password
#                 )
#                 return redirect('/')
#
#     return render(request, 'user_login.html', {'message': message})


def users_list(request):
    users = UserAccount.objects.all()
    return render(request, 'users_list.html', {'users': users})


    # OR, if it's inside app/templates/app/
    # return render(request, 'app/users_list.html')

def add_to_cart(request, product_id):
    cart = request.session.get('cart', [])
    cart.append(product_id)
    request.session['cart'] = cart
    return redirect('cart')

def cart_view(request):
    cart = request.session.get('cart', [])
    products = Product.objects.filter(id__in=cart)
    return render(request, 'cart.html', {'products': products})



# def buy_now(request):
#     return render(request, 'buy_now.html')

def remove_from_cart(request, product_id):
    cart = request.session.get('cart', [])

    if product_id in cart:
        cart.remove(product_id)

    request.session['cart'] = cart
    return redirect('cart')

# def user_login(request):
#     if request.method == 'POST':
#         action = request.POST.get('action')
#
#         if action == 'login':
#             username = request.POST.get('username')
#             password = request.POST.get('password')
#
#             user = UserAccount.objects.filter(username=username, password=password).first()
#
#             if user:
#                 request.session['logged_user'] = user.username
#                 return redirect('/')
#
#     return render(request, 'user_login.html')



def user_login(request):
    message = ""

    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'login':
            username = request.POST.get('username', '').strip()
            password = request.POST.get('password', '').strip()

            user = UserAccount.objects.filter(
                username=username,
                password=password
            ).first()

            if user:
                request.session['logged_user'] = username
                return redirect('/home/')

            message = "Wrong username or password"

        elif action == 'signup':
            username = request.POST.get('new_username', '').strip()
            password = request.POST.get('new_password', '').strip()

            if username and password:
                if not UserAccount.objects.filter(username=username).exists():
                    UserAccount.objects.create(
                        username=username,
                        password=password
                    )
                    request.session['logged_user'] = username
                    return redirect('/')

                message = "Username already exists"

    return render(request, 'user_login.html', {'message': message})


def increase_cart(request, product_id):
    cart = request.session.get('cart', [])
    cart.append(product_id)
    request.session['cart'] = cart
    return redirect('/cart/')

def decrease_cart(request, product_id):
    cart = request.session.get('cart', [])

    if product_id in cart:
        cart.remove(product_id)

    request.session['cart'] = cart
    return redirect('/cart/')

from django.shortcuts import render, redirect, get_object_or_404
from .models import Product

def manage_products(request):
    products = Product.objects.all()

    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        price = request.POST.get('price')
        image = request.FILES.get('image')

        Product.objects.create(
            name=name,
            description=description,
            price=price,
            image=image
        )

        return redirect('/manage-products/')

    return render(request, 'manage_products.html', {'products': products})


def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    product.delete()
    return redirect('/manage-products/')


def edit_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    if request.method == 'POST':
        product.name = request.POST.get('name')
        product.description = request.POST.get('description')
        product.price = request.POST.get('price')

        if request.FILES.get('image'):
            product.image = request.FILES.get('image')

        product.save()
        return redirect('/manage-products/')

    return render(request, 'edit_product.html', {'product': product})

# def cart_view(request):
#     cart = request.session.get('cart', [])
#     products = Product.objects.filter(id__in=cart)
#
#     total = sum(product.price for product in products)
#
#     return render(request, 'cart.html', {
#         'products': products,
#         'total': total
#     })

from collections import Counter
from django.shortcuts import render
from .models import Product

def cart_view(request):
    cart = request.session.get('cart', [])
    counts = Counter(cart)

    products = Product.objects.filter(id__in=counts.keys())

    cart_items = []
    total = 0

    for product in products:
        qty = counts[product.id]
        subtotal = float(product.price) * qty
        total += subtotal

        cart_items.append({
            'product': product,
            'qty': qty,
            'subtotal': subtotal
        })

    return render(request, 'cart.html', {
        'cart_items': cart_items,
        'total': total
    })

from collections import Counter
from .models import Product

def buy_now(request):
    cart = request.session.get('cart', [])

    counts = Counter(cart)
    products = Product.objects.filter(id__in=counts.keys())

    total = 0

    for product in products:
        qty = counts[product.id]
        total += float(product.price) * qty

    return render(request, 'buy_now.html', {
        'total': total
    })