from django.contrib import admin
from .models import Product, UserAccount

admin.site.register(Product)
admin.site.register(UserAccount)